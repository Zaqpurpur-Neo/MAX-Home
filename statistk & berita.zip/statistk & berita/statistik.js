document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector(".container-form");
    const bmrOutput = document.querySelector("#bmr-value .value-number");
    const allOutputs = document.querySelectorAll(".statistics-value .value-number");

    const tdeeOutput = allOutputs[1];
    const idealWeightOutput = allOutputs[2];
    const statusBBOutput = allOutputs[3];

    form.querySelector("button").addEventListener("click", function (e) {
        e.preventDefault();

        const gender = document.getElementById("gender").value;
        const age = parseInt(document.getElementById("age").value);
        const weight = parseFloat(document.getElementById("weight").value);
        const height = parseFloat(document.getElementById("height").value);
        const fitness = document.getElementById("fitness").value;

        if (isNaN(age) || isNaN(weight) || isNaN(height)) {
            alert("Silakan isi semua data dengan benar.");
            return;
        }

        // Hitung BMR
        let bmr = gender === "male"
            ? 10 * weight + 6.25 * height - 5 * age + 5
            : 10 * weight + 6.25 * height - 5 * age - 161;

        // Hitung TDEE
        const activityLevels = {
            low: 1.2,
            medium: 1.55,
            high: 1.725
        };
        const activityFactor = activityLevels[fitness];
        const tdee = bmr * activityFactor;

        // Berat Badan Ideal (Broca)
        const idealWeight = gender === "male"
            ? (height - 100) - (height - 100) * 0.1
            : (height - 100) - (height - 100) * 0.15;

        // Status BB (berdasarkan BMI)
        const bmi = weight / ((height / 100) ** 2);
        let statusBB = "";
        if (bmi < 18.5) {
            statusBB = "Kurus";
        } else if (bmi < 25) {
            statusBB = "Ideal";
        } else if (bmi < 30) {
            statusBB = "Gemuk";
        } else {
            statusBB = "Obesitas";
        }

        // Tampilkan hasil
        bmrOutput.textContent = Math.round(bmr);
        tdeeOutput.textContent = Math.round(tdee);
        idealWeightOutput.textContent = Math.round(idealWeight);
        statusBBOutput.textContent = statusBB;
    });
});
